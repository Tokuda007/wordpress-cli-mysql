<?php
namespace Ari_Adminer\Models;

defined( 'ABSPATH' ) or die( 'Access forbidden!' );

use Ari\Models\Model as Model;

class Settings extends Model {}

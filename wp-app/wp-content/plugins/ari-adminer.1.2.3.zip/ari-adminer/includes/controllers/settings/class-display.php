<?php
namespace Ari_Adminer\Controllers\Settings;

defined( 'ABSPATH' ) or die( 'Access forbidden!' );

use Ari\Controllers\Display as Display_Controller;

class Display extends Display_Controller {}
<?php
defined( 'ABSPATH' ) or die( 'Access forbidden!' );

$connection->select_db($adminer->database());

<?php
namespace Ari\Models;

defined( 'ABSPATH' ) or die( 'Access forbidden!' );

use Ari\Utils\Options as Options;

class Model_Options extends Options {
    public $class_prefix  = '';
}
